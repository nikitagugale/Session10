# My lab log

Fill this in as you go: two or three lines per milestone is plenty. It is for you (and it is what you would show a colleague to say
"here is how I got there"). Nobody marks it.

| | Milestone | Done at | Hints taken | Used Claude? |
|---|---|---|---|---|
| 1 | Find the over-broad credential | | | |
| 2 | Work out what the tools really need | | | |
| 3 | Design the scoped token | | | |
| 4 | Validate the token properly | | | |
| 5 | Protect freeze_card | | | |
| 6 | Prove it with tests | | | |
| 7 | Leave an audit trail | | | |
| 8 | Close the confused-deputy hole | | | |

(`npm run progress` shows hints taken and what is done.)

---

## Milestone 1 · Find the over-broad credential
- **The command that gave me each fact:**
- **Something that surprised me:**

## Milestone 2 · Work out what the tools really need
- **My judgement call (and why):**

## Milestone 3 · Design the scoped token
- **The claim I thought hardest about, and why:**

## Milestone 4 · Validate the token properly
- **My brief to Claude (paste it or summarise it):**
- **What Claude got right, and what I had to correct:**
- **Why each problem was exploitable (one sentence each):**

## Milestone 5 · Protect freeze_card
- **What I changed:**
- **The difference between a 401 and a 403, in my words:**

## Milestone 6 · Prove it with tests
- **My brief to Claude:**
- **Which of my tests failed against the starter helper, and why that is good:**

## Milestone 7 · Leave an audit trail
- **Where I write the entry, and why there:**
- **What I decided never to log:**

## Milestone 8 · Close the confused-deputy hole
- **What the endpoint forgot to ask:**
- **Why a missing account and somebody else's account must answer the same:**

---

## At the end
- **Three things I will do differently in my own work:**
- **One thing I am still not sure about:**
